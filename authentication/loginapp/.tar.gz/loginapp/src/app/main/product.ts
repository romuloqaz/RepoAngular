export interface Product {
    name: string;
    department: string;
    price: number;
}
